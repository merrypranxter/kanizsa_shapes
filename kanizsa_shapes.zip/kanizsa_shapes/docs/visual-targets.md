# Visual Targets: kanizsa_shapes

> TODO: describe desired visual output, color palettes, and animation behavior.
