// TODO: brightness.frag
