// Pac-man and line-termination inducer geometry
