// Kanizsa illusion renderer
