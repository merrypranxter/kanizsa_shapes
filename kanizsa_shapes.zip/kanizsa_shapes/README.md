# kanizsa_shapes

> pac-man inducers. missing edges. the brain draws the rest.

Kanizsa-type illusory contour generator. Configurable inducer arrangements (pac-man sectors, line terminations, figure-ground) produce shapes that are not physically present in the image. The brain’s contour completion mechanisms create vivid triangles, squares, and subjective surfaces. Parameterize inducer rotation, gap size, and contrast to explore the illusion space.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Cycle shape type (triangle / square / disk / cross) |
| `R` | Rotate all inducers |
| `G` | Adjust gap size |
| `C` | Toggle contrast inversion |
| `B` | Toggle subjective brightness fill |
| `F` | Toggle figure-ground ambiguity |

## Named Regimes

- **Kanizsa Triangle** — Classic 3-inducer triangle
- **Kanizsa Square** — 4-inducer square with subjective brightness
- **Subjective Disk** — Circular illusory contour
- **Neon Spreading** — Color diffuses beyond physical edges
- **Figure-Ground** — Vase/faces ambiguity with contour completion
- **Ebbinghaus** — Context size illusion (bonus)

## The Math

Inducer geometry:
- Pac-man sector: angle θ (typically 60°–90°)
- Gap size: g = distance between inducer tips
- Illusion strength ∝ 1/g (smaller gap = stronger)
- Illusion strength ∝ contrast

Subjective brightness model:
- The illusory shape region receives a brightness boost
- Boost magnitude depends on inducer contrast and number
- Lateral inhibition: inducers are darker, making the interior appear lighter by comparison

## Acknowledgments

Gaetano Kanizsa, *Organization in Vision* (1979), V2 neuron research by von der Heydt and Peterhans.
